import albumentations as A


def lane_normalize():
    return A.Normalize()
